# panther-detections
Built-in Panther detection rules and policies
